from rdkit import Chem
import json
import copy

RDKIT_SMILES_PARSER_PARAMS = Chem.SmilesParserParams()


def str_to_mol(string: str, explicit_hydrogens: bool = True) -> Chem.Mol:
    """
    Converts a SMILES string to an RDKit molecule.

    :param string: The InChI or SMILES string.
    :param explicit_hydrogens: Whether to treat hydrogens explicitly.
    :return: The RDKit molecule.
    """
    if string.startswith('InChI'):
        mol = Chem.MolFromInchi(string, removeHs=not explicit_hydrogens)
    else:
        RDKIT_SMILES_PARSER_PARAMS.removeHs = not explicit_hydrogens
        mol = Chem.MolFromSmiles(string, RDKIT_SMILES_PARSER_PARAMS)

    if explicit_hydrogens:
        return Chem.AddHs(mol)
    else:
        return Chem.RemoveHs(mol)


def assign_map_num(smi, explicit_hydrogens: bool = True):
    """
    This function is to check and assign the atom map numbers

    Args:
        smi: the smiles string to be checked
        explicit_hydrogens: whether assign atom numbers of hydrogen numbers

    Returns: None

    """
    mol = str_to_mol(smi, explicit_hydrogens=explicit_hydrogens)
    # Check if smi has atom map numbers
    assign_num = False
    for atom in mol.GetAtoms():
        if atom.GetAtomMapNum() == 0:
            assign_num = True
            break
    # if any atom without map_num
    if assign_num is True:
        for atom in mol.GetAtoms():
            atom.SetAtomMapNum(atom.GetIdx() + 1)
    else:
        return smi

    return Chem.MolToSmiles(mol)


def drop_map_num(smi: str):
    """
    Drop the atom map number to get the canonical smiles
    Args:
        smi: the molecule smiles

    Returns:

    """
    mol = Chem.MolFromSmiles(smi)
    for atom in mol.GetAtoms():
        atom.SetAtomMapNum(0)
    return Chem.MolToSmiles(mol)


def drop_Hs_map_num(smi):
    mol = Chem.MolFromSmiles(smi)
    for atom in mol.GetAtoms():
        if atom.GetSymbol() == 'H':
            atom.SetAtomMapNum(0)
    return Chem.MolToSmiles(mol)


def return_attr(obj, name: str):
    """
    Check whether the object has the "name" attribute
    Args:
        obj:
        name:

    Returns:

    """
    if hasattr(obj, name):
        return getattr(obj, name)
    else:
        raise KeyError("{} object does not have {} attribute!".format(obj, name))


def read_temp(temp_path, reverse: bool = True):
    dic_path = temp_path
    file = open(dic_path, 'r')
    js = file.read()
    react_dic = json.loads(js)
    file.close()
    react_dic_reverse = {}
    if reverse:
        for key, value in react_dic.items():
            reac_temp = value['reaction_smarts']
            if 'reversible' in value.keys() and value['reversible'] == 'True':
                reversible = True
            else:
                reversible = False

            if reac_temp in [None, {}, ''] or not reversible:
                continue
            key_re = key + '_re'
            react_dic_reverse[key_re] = {}
            react_dic_reverse[key_re]['reaction_smarts'] = value['reaction_smarts'].split('>')[-1] + '>>' + \
                                                        value['reaction_smarts'].split('>')[0]
            react_dic_reverse[key_re]['react_temp_radical'] = value['prod_temp_radical']
            react_dic_reverse[key_re]['prod_temp_radical'] = value['react_temp_radical']

    return react_dic, react_dic_reverse


def check_atom_map_num(rxn: str, explicit_hydrogens: bool = False, all_mpped: bool = False, show_info: bool = True):
        """
        Check atom map numbers between reactants and products
        Args:
            rxn: A reaction string like reactant>>product
            explicit_hydrogens: compare hydrogen atoms?
            all_mpped: Is all atoms aremapped?
            show_info: print error information

        Returns: bool
        """
        reactant, product = rxn.split(">")[0], rxn.split(">")[-1]
        rmol = str_to_mol(reactant, explicit_hydrogens=explicit_hydrogens)
        pmol = str_to_mol(product, explicit_hydrogens=explicit_hydrogens)
        p_num_idx_map = {atom.GetAtomMapNum(): atom.GetIdx() for atom in pmol.GetAtoms()}
        if all_mpped:
            assert 0 not in p_num_idx_map.keys(), "Unmapped atom in reaction {}".format(rxn)
        for r_atom in rmol.GetAtoms():
            r_map_num = r_atom.GetAtomMapNum()
            p_atom = pmol.GetAtomWithIdx(p_num_idx_map[r_map_num])
            if r_atom.GetSymbol() == p_atom.GetSymbol():
                continue
            else:
                if show_info:
                    print("Matching interrupt for {}th atom in reactant and product".format(r_map_num))
                return False

        return True


def SetSymm(symm: list, molecule: str) -> list:
    """
    Set atom-map numbers of symmetry molecules to same(the first map number in symmetry set)
    Args:
        symm: the symmetry list such as [{1, 2, 3}, {4, 5, 6}]
        molecule: A SMILES list suc as [A-mapped, B-mapped]
    Returns: atom-map molecule list

    """
    if drop_Hs_map_num(molecule) == '[H][H]' or drop_Hs_map_num(molecule) == '[H].[H]':
        mol = str_to_mol(molecule)
    else:
        mol = str_to_mol(drop_Hs_map_num(molecule), explicit_hydrogens=False)
    num_idx_map = {atom.GetAtomMapNum(): atom.GetIdx() for atom in mol.GetAtoms()}
    for same_atoms in symm:
        same_atoms = list(same_atoms)
        for num in list(same_atoms)[1:]:
            mol.GetAtomWithIdx(num_idx_map[num]).SetAtomMapNum(same_atoms[0])
    new_smi = Chem.MolToSmiles(mol)

    return new_smi
