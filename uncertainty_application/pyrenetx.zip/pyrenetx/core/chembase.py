import os
from typing import Union, List
import inspect

from rdkit import Chem
from rdkit.Chem import rdChemReactions
import rdkit.Chem.AllChem as AllChem
from rdkit.Chem import Descriptors

from .util import str_to_mol, drop_map_num, assign_map_num, drop_Hs_map_num, read_temp, SetSymm
from .rdradical.main import rdradicalRunText
from .rdradical import extractor_radical_invert


class Molecule:
    """
    A molecule class
    """

    def __init__(self, smiles: str, explicit_hydrogens: bool = True, name: str = None):
        """
        Initialize the Molecule class
        Args:
            smiles:
            explicit_hydrogens:
        """
        self._explicit_hydrogens = explicit_hydrogens
        self._mol = str_to_mol(smiles, explicit_hydrogens=self._explicit_hydrogens)
        self._smiles = Chem.MolToSmiles(self._mol, allHsExplicit=self._explicit_hydrogens)
        default_name = ["None"] * len(self._smiles.split("."))
        for i, n in enumerate(str(name).split(".")):
            default_name[i] = n
        self._name = ".".join(default_name)

    def __call__(self, **kwargs):
        self.update(**kwargs)

        return self

    def __hash__(self):

        return hash(self._smiles)

    def __str__(self):

        return self._smiles

    def __repr__(self):

        return "{}:{}".format(self._name, self._smiles)

    def __len__(self):

        return len(self._smiles.split("."))

    def __add__(self, other):
        """
        Merge two molecules
        Args:
            other:

        Returns: merged smiles
        """
        """
        self._smiles = ".".join([self._smiles, other.smiles])
        self._explicit_hydrogens = self._explicit_hydrogens | other._explicit_hydrogens
        self._mol = str_to_mol(self._smiles)
        self._name = ".".join([str(self._smiles), str(other)])
        """
        smiles = ".".join([self._smiles, other.smiles])
        explicit_hydrogens = self._explicit_hydrogens | other.explicit_hydrogens
        name = ".".join([str(self.name), str(other.name)])

        return Molecule(smiles, explicit_hydrogens, name)

    def __eq__(self, other):
        """

        Args:
            other:

        Returns:

        """
        assert self.smiles is not None and other.smiles is not None

        return self.smiles == other.smiles

    def __ne__(self, other):
        assert self.smiles is not None and other.smiles is not None

        return self.smiles != other.smiles

    def __iter__(self):
        self._iter = self._smiles.split(".")
        self._iter_len = len(self._smiles.split("."))
        self._iter_name = self._name.split(".")
        self._iter_idx = 0
        return self

    def __next__(self):
        if self._iter_idx < self._iter_len:
            ret = self._iter[self._iter_idx]
            name = self._iter_name[self._iter_idx]
            self._iter_idx += 1
            return Molecule(ret, self._explicit_hydrogens, name)
        else:
            raise StopIteration

    def update(self, **kwargs):
        keys = kwargs.keys()
        args = inspect.getfullargspec(self.__init__).args
        for key in keys:
            if key in args:
                setattr(self, "_{}".format(key), kwargs[key])
            else:
                raise KeyError("Unknown parameter")

        self._mol = str_to_mol(self._smiles, explicit_hydrogens=self._explicit_hydrogens)
        self._smiles = Chem.MolToSmiles(self._mol)
        return self

    def assign_map_num(self):
        """
        Assign atom map number
        Returns: None
        """
        self._smiles = assign_map_num(self._smiles, self._explicit_hydrogens)
        self._mol = str_to_mol(self._smiles, explicit_hydrogens=self._explicit_hydrogens)
        return self

    def drop_map_num(self):
        """
        Drop atom map number
        Returns: None
        """
        self._smiles = drop_map_num(self._smiles)
        self._mol = str_to_mol(self._smiles, explicit_hydrogens=self._explicit_hydrogens)
        return self

    def drop_Hs_map_num(self):
        """
        Drop H atom map number
        Returns: None
        """
        self._smiles = drop_Hs_map_num(self._smiles)
        self._mol = str_to_mol(self._smiles, explicit_hydrogens=self._explicit_hydrogens)
        return self

    def symmetry(self) -> list:
        """
        Find symmetry of molecules
        Returns: a list if the molecules are symmetric
        """
        symmetric: List[Union[bool, dict]] = [False] * len(self)
        for ith, Mole in enumerate(self):
            mol = Mole.mol
            sym = mol.GetSubstructMatches(mol, uniquify=False)
            if len(sym) <= 1:
                continue

            mol_dict = {atom.GetIdx(): atom.GetAtomMapNum() for atom in mol.GetAtoms()}
            if 0 in mol_dict.values():
                for atom in mol.GetAtoms():
                    atom.SetAtomMapNum(atom.GetIdx() + 1)
                    mol_dict[atom.GetIdx()] = atom.GetIdx() + 1
            matched_dict = {}
            for idxs in sym:
                matching_dict = {atom.GetAtomMapNum(): mol_dict[idx] for atom, idx in zip(mol.GetAtoms(), idxs)}
                for key, value in matching_dict.items():
                    if key == value:
                        continue
                    else:
                        if key not in matched_dict.keys():
                            matched_dict[key] = [value]
                        else:
                            matched_dict[key].append(value)

            # match dict has been generated, check duplication
            if matched_dict == {}:
                continue
            else:
                results = []
                for init, match in matched_dict.items():
                    result = set(match)
                    result.add(init)
                    if len(result) > 1 and result not in results:
                        results.append(result)
                    else:
                        continue
                info_dict = {"molecule{}".format(ith + 1): Chem.MolToSmiles(mol), "symmetry": results}
            symmetric[ith] = info_dict

        return symmetric

    @property
    def explicit_hydrogen(self) -> bool:

        return self._explicit_hydrogens

    @property
    def mol(self):

        return self._mol

    @property
    def smiles(self) -> str:

        return str(self._smiles)

    @property
    def name(self) -> str:

        return str(self._name)


class Reaction:
    """
    A reaction class
    """

    def __init__(self, reaction: str, reaction_name: str = None, reactant_name: str = None, product_name: str = None,
                 explicit_hydrogens: bool = True, prop: dict = dict({})):
        """
        Initialize reaction
        Args:
            reaction: reactions smiles
            reaction_name:
            reactant_name:
            product_name:
            explicit_hydrogens:
            prop: properties that can't be dented by reaction smiles such as catalyse, reaction conditions
        """
        self._prop = prop
        self._reaction_name = reaction_name
        self._explicit_hydrogens = explicit_hydrogens
        self._reactant_name = reactant_name
        self._product_name = product_name

        reaction_info = reaction.split('>')
        assert len(reaction_info) == 3, 'Reaction SMILES consists of three parts denoting reactants, agents and ' \
                                        'products, separated by ">"'
        self._reactant = Molecule(reaction_info[0], self._explicit_hydrogens, reactant_name)
        self._rsmi = self._reactant.smiles
        self._product = Molecule(reaction_info[-1], self._explicit_hydrogens, reactant_name)
        self._psmi = self._product.smiles
        self._agent = Molecule(reaction_info[1], self._explicit_hydrogens, reactant_name)
        self._agtsmi = self._agent.smiles

        self._reaction = ">".join([str(self._rsmi), str(self._agtsmi), str(self._psmi)])

    def __call__(self, **kwargs):

        self.update(**kwargs)
        return self

    def __str__(self):

        return self._reaction

    def __hash__(self):
        return hash(self._reaction)

    def __eq__(self, other):
        assert type(other).__name__ == "Molecule", "Inconsistent types: {} and {}".format(self.name, other)
        if self.reactant == other.reactant and self.product == other.product and self.agent == other.agent:
            return True
        else:
            return False

    def __ne__(self, other):
        assert type(other).__name__ == "Molecule", "Inconsistent types: {} and {}".format(self.name, other)
        if self.reactant == other.reactant or self.product == other.product and self.agent == other.agent:
            return False
        else:
            return True

    def update(self, **kwargs):
        """
        Update reaction attributes
        Args:
            **kwargs: The updated parameters
        Returns:

        """
        args = inspect.getfullargspec(self.__init__).args
        keys = kwargs.keys()
        for key in keys:
            if key not in args:
                raise KeyError("Unknown parameter {}!".format(key))
            else:
                setattr(self, '_{}'.format(key), kwargs[key])

        reaction_info = self._reaction.split('>')
        assert len(reaction_info) == 3, 'Reaction SMILES consists of three parts denoting reactants, agents and ' \
                                        'products, separated by ">"'
        self._reactant = Molecule(reaction_info[0], self._explicit_hydrogens, self._reactant_name)
        self._rsmi = self._reactant.smiles
        self._product = Molecule(reaction_info[-1], self._explicit_hydrogens, self._reactant_name)
        self._psmi = self._product.smiles
        self._agent = Molecule(reaction_info[1], self._explicit_hydrogens, self._reactant_name)
        self._agtsmi = self._agent.smiles

        self._reaction = ">".join([str(self._rsmi), str(self._agtsmi), str(self._psmi)])

        return self

    def drop_map_number(self):

        reaction = '>'.join([self._reactant.drop_map_num().smiles, self._agent.drop_map_num().smiles,
                            self._product.drop_map_num().smiles])

        return self.update(reaction=reaction)

    def drop_Hs_map_number(self):

        reaction = '>'.join([self._reactant.drop_Hs_map_num().smiles, self._agent.drop_Hs_map_num().smiles,
                             self._product.drop_Hs_map_num().smiles])

        return self.update(reaction=reaction)

    @property
    def explicit_hydrogens(self):

        return self._explicit_hydrogens

    @property
    def name(self) -> str:

        return self._reaction_name

    @property
    def reaction(self) -> str:

        return self._reaction

    @property
    def reactant_smiles(self) -> str:

        return self._rsmi

    @property
    def product_smiles(self) -> str:

        return self._psmi

    @property
    def agent_smiles(self) -> str:

        return self._agtsmi

    @property
    def reactant(self):

        return self._reactant

    @property
    def product(self):

        return self._product

    @property
    def agent(self):

        return self._agent

    @property
    def prop(self):

        return self._prop


class RunReactions:
    """
    A class for run reactions
    This class is a wrapper of rdradical
    """

    def __init__(self,
                 explicit_hydrogens: bool = True,
                 name: str = None,
                 templates: dict = dict({})):
        self._name = name
        self._templates = templates
        self._explicit_hydrogens = explicit_hydrogens
        if self._templates:
            RunReactions.check_templates(self._templates)

    @staticmethod
    def check_templates(template: dict):
        """
        Check illegal templates
        Args:
            template:
        Returns: dict
        """
        for name, smarts_dict in template.items():
            assert type(smarts_dict).__name__ == "dict", "{}: reaction information should be a dictionary".format(name)
            keys = smarts_dict.keys()
            for key in ['reaction_smarts', 'react_temp_radical', 'prod_temp_radical']:
                if key not in keys:
                    raise KeyError("Missing {} of reaction {}".format(key, name))
            try:
                AllChem.ReactionFromSmarts(smarts_dict["reaction_smarts"])
            except Exception as e:
                raise Exception("{}::{}: Illegal reaction smarts".format(e, name))

    def load_template(self, path: str = None, template: dict = None, reversible: bool = True):
        template_dict = {}
        if path:
            assert os.path.isfile(path), "Unknown path"
            temp_dict, temp_dic_reverse = read_temp(path, reverse=reversible)
            template_dict.update(temp_dict)
            template_dict.update(temp_dic_reverse)
        if template:
            template_dict.update(template)
        if template_dict == {}:
            pass
        else:
            RunReactions.check_templates(template_dict)
            self._templates.update(template_dict)

    def add_template(self, template: dict):

        RunReactions.check_templates(template)
        self._templates.update(template)

    def drop_template(self, template_name: Union[str, list]):
        if type(template_name).__name__ == "str" and template_name in self._templates.keys():
            del self._templates[template_name]
        else:
            for temp_name in template_name:
                if temp_name in self._templates.keys():
                    del self._templates[template_name]

    @staticmethod
    def extract_template(rxn: str, idx: int = 0):
        """
        Extract reaction template for given reactant
        Args:
            rxn: a reaction string like reactant_smiles >> product_smiles
            idx: the reaction index

        Returns:
        """
        reaction = {}
        rsmi, psmi = rxn.split(">")[0], rxn.split(">")[-1]
        reaction['reactants'] = rsmi
        reaction['products'] = psmi
        reaction['_id'] = idx
        return extractor_radical_invert.extract_from_reaction(reaction)

    def run(self, reactant: Union[str, Molecule], maxRadicalElectrons: int = 3):
        """
        Run the given template and drop same reactions
        Note: Hydrogen atoms at same heavy atom are considered identical
        Args:
            reactant: Two molecules at most
            maxRadicalElectrons: Maximum number of radical electrons

        Returns: a dict contain the generated reactions:
        {rsmi: {Hs_droped_product: (product_with_Hs, change_atom_map_num)}}

        """

        rmole = reactant if type(reactant).__name__ == "Molecule" else Molecule(reactant, self._explicit_hydrogens)
        RunReactions.check_templates(self._templates)

        rsmi_list = rmole.assign_map_num().smiles.split(".")
        if len(rsmi_list) == 1:
            rsmis = rsmi_list
        elif len(rsmi_list) == 2:
            rsmis = [".".join([rsmi_list[0], rsmi_list[-1]]), ".".join([rsmi_list[-1], rsmi_list[0]])]
        else:
            raise Exception("Unsupported molecule numbers")

        # Find symmetric atoms
        results = dict({})
        for rsmi in rsmis:
            outcome_info = dict({})
            symmetry = rmole.update(explicit_hydrogens=False).symmetry()
            sym_atom_map = list([])
            for idx, sym in enumerate(symmetry):
                if sym:
                    if drop_map_num(sym["molecule{}".format(idx + 1)]) != "[H][H]":
                        sym_atom_map.extend(sym["symmetry"])
            for name, smarts_dict in self._templates.items():
                # run reactant by rdkit. react_temp: reaction SMARTS; rad_rt: dictionary; rad_pt:dictionary
                smarts = smarts_dict['reaction_smarts']
                rad_rt = smarts_dict['react_temp_radical']
                rad_pt = smarts_dict['prod_temp_radical']
                # Check reactant and reactant SMARTS length. For grouped fragments of one/more molecules:
                # (SMARTS), (SMARTS).(SMARTS), (SMARTS).SMARTS
                if len(rmole) != rdChemReactions.ReactionFromSmarts(smarts).GetNumReactantTemplates():
                    continue
                else:
                    mapped_outcomes = dict({})
                    outcomes_rdchirl, mapped_outcome, mapped_outcome_dup = rdradicalRunText(smarts, rad_rt, rad_pt,
                                                                                            rsmi)
                    # Note: mapped_outcome containing:
                    # {mapped_outcome(without H): (mapped_outcome_with_H, (changed atoms))}
                    if mapped_outcome == {}:
                        continue
                    else:
                        # try another way
                        if sym_atom_map:
                            sym_keys = []
                            keys = list(mapped_outcome.keys())
                            values = list(mapped_outcome.values())
                            for key, value in zip(keys, values):
                                num_rad = Descriptors.NumRadicalElectrons(Chem.MolFromSmiles(key))
                                sym_key = SetSymm(symm=sym_atom_map, molecule=key)
                                if sym_key in sym_keys or num_rad > maxRadicalElectrons:
                                    del mapped_outcome[key]
                                else:
                                    sym_keys.append(key)

                        outcome_info[name] = mapped_outcome

                results[rsmi] = outcome_info

        return results

    @property
    def templates(self):
        return self._templates

    @property
    def template_names(self):
        return self._templates.keys()
