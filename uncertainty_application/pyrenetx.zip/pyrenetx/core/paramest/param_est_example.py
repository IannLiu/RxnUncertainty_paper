import pandas as pd
from pyomo.environ import *
from .util import create_data_dict
import kinestor

if __name__ == "__main__":
    data_dir = './data/'

    # read-in file names from log file created using gen_data()
    file_list = pd.read_csv(data_dir + 'parmest_log_file.csv')
    data_dict_overall = create_data_dict(file_list)

    # declare model
    m = kinestor.ReactionModel()
    # load reaction constants
    Constants = kinestor.Constant()
    R = Constants.get_constant(con_name="R")
    # T = 250
    A1 = m.parameter("A1", initialize=200, bounds=(100, 300))
    A2 = m.parameter("A2", initialize=400, bounds=(300, 500))
    E1 = m.parameter("E1", initialize=10, bounds=(1, 20))
    E2 = m.parameter("E2", initialize=15, bounds=(1, 30))
    T = m.set_temperature()
    k1 = m.form_rate_constant("k1", A1 * exp(-E1*1000/(R*T)))
    k2 = m.form_rate_constant("k2", A2 * exp(-E2*1000/(R*T)))

    CA = m.component("CA")
    CB = m.component("CB")
    CC = m.component("CC")
    m.add_ode("CA", -k1 * CA)
    m.add_ode("CB", k1 * CA - k2 * CB)
    m.add_ode("CC", k2 * CB)
    m.add_data(data_dict_overall)
    theta = m.opt(cal_cov=True, cov_n=348)
    # m.report()
    print(theta)

