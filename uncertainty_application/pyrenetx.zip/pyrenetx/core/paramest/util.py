import pandas as pd
from pyomo.environ import *
from pyomo.dae import *


def create_data_dict(files):
    '''
    Create a list of dictionaries from multiple datasets
    Arguments:
        files: pandas dataframe of file names
    Return:
        data_dict_list: list of dictionaries
    '''
    data_dict_list = []
    for index, file in files.iterrows():
        # create a dictionary of 'experimental' data for temperature T and initial concentration of A CA0
        data_dict = {}
        data = pd.read_csv(str(file.values[0]),index_col=0)
        data_dict['T'] = data['T'].iloc[0]
        data_dict['CA0'] = data['CA0'].iloc[0]
        data = data.drop(labels=['T','CA0'],axis=1)
        data_dict['data'] = data
        # add dictionary to list to be return
        data_dict_list.append(data_dict)
    return data_dict_list


def create_model_DAE(data):
    '''
    function to create Pyomo model
    Argument:
        data: a single dictionary of data
    Return:
        m: Pyomo model
    '''
    # data
    exp_data = data['data']

    # This code style matches parmest example found here:
    # https://github.com/Pyomo/pyomo/blob/master/pyomo/contrib/parmest/examples/semibatch/semibatch.py

    # unpack 'experimental' data into temporary variables
    cameastemp = exp_data['CA']
    cbmeastemp = exp_data['CB']
    ccmeastemp = exp_data['CC']
    tmeastemp = exp_data['time']

    # create dictionaries for 'experimental' data of CA, CB,and CC indexed by timestep
    cameas = {}
    cbmeas = {}
    ccmeas = {}
    for i, j in enumerate(tmeastemp):
        cameas[float(j)] = cameastemp[i]
        cbmeas[float(j)] = cbmeastemp[i]
        ccmeas[float(j)] = ccmeastemp[i]

    # define Pyomo model
    m = ConcreteModel()
    m.T = data['T']  # K
    m.CA0 = data['CA0']  # mol/L

    # define 'experimental' data timesteps as Pyomo ContinuousSet
    m.t = ContinuousSet(bounds=(0.0, tmeastemp.iloc[-1]), initialize=tmeastemp.tolist())

    # define 'experimental' data as Pyomo parameters indexed by timestep set and
    # initialized by dictionary of experimental data
    m.Ca_meas = Param(m.t, initialize=cameas)
    m.Cb_meas = Param(m.t, initialize=cbmeas)
    m.Cc_meas = Param(m.t, initialize=ccmeas)

    m.R = 8.31446261815324  # J / K / mole

    # Kinetic parameters to be fitted defined as Pyomo variables
    # Initialized by 'true' values
    m.A1 = Var(initialize=200, bounds=(100, 300))  # 1/hr
    m.A2 = Var(initialize=400, bounds=(300, 500))  # 1/hr
    m.E1 = Var(initialize=10, bounds=(1, 20))  # kJ/mol
    m.E2 = Var(initialize=15, bounds=(1, 30))  # kJ/mol

    # Concentration variables indexed by time
    m.CA = Var(m.t, initialize=m.CA0)  # mol/L
    m.CB = Var(m.t, initialize=0)  # mol/L
    m.CC = Var(m.t, initialize=0)  # mol/L

    # Derivatives in the model
    #
    m.dCA = DerivativeVar(m.CA)
    m.dCB = DerivativeVar(m.CB)
    m.dCC = DerivativeVar(m.CC)

    # kinetic rate constants from Arrhenius equation
    m.k1 = Expression(rule=m.A1 * exp(-m.E1 * 1000 / (m.R * m.T)))  # 1/hr
    m.k2 = Expression(rule=m.A2 * exp(-m.E2 * 1000 / (m.R * m.T)))  # 1/hr

    # Constraints to change concentrations based on kinetics
    def conc_A(m, i):
        return m.dCA[i] == - m.k1 * m.CA[i]

    m.CA_rate = Constraint(m.t, rule=conc_A)

    def conc_B(m, i):
        return m.dCB[i] == m.k1 * m.CA[i] - m.k2 * m.CB[i]

    m.CB_rate = Constraint(m.t, rule=conc_B)

    def conc_C(m, i):
        return m.dCC[i] == m.k2 * m.CB[i]

    m.CC_rate = Constraint(m.t, rule=conc_C)

    # Initial Conditions
    def _initcon(m):
        yield m.CA[m.t.first()] == m.CA0
        yield m.CB[m.t.first()] == 0.0
        yield m.CC[m.t.first()] == 0.0

    m.initcon = ConstraintList(rule=_initcon)

    # Objective function
    # The objective function for parmest is defined as a 2-stage stochastic optimization objective function

    # First stage cost: independent of scenarios ('experiments')
    #                   expression for minimizing fixed realization
    #                   from model. Eg.: reactor temperature, size, etc.
    def ComputeFirstStageCost_rule(m):
        # In this case, we do not optimize anything besides the kinetic parameters through
        # least square fitting realizations at each timestep defined by m.t.
        # Hence, the first stage cost is set to 0 here.
        return 0

    m.FirstStageCost = Expression(rule=ComputeFirstStageCost_rule)

    # Second stage cost: Realization at each scenario over which the model is defined
    def ComputeSecondStageCost_rule(m):
        # In this problem, we want to minimize the sum of squared errors between
        # 'experimental' data and the model realization of concentrations of
        # A, B, and C over each scenario (here, timesteps defined by m.t)
        return sum((m.CA[t] - m.Ca_meas[t]) ** 2 + (m.CB[t] - m.Cb_meas[t]) ** 2
                   + (m.CC[t] - m.Cc_meas[t]) ** 2 for t in m.t)

    m.SecondStageCost = Expression(rule=ComputeSecondStageCost_rule)

    # return the sum of the first-stage and second-stage costs as the objective function
    def total_cost_rule(m):
        return m.FirstStageCost + m.SecondStageCost

    m.Total_Cost_Objective = Objective(rule=total_cost_rule, sense=minimize)

    # Discretize model
    disc = TransformationFactory('dae.collocation')
    # The DAE model is discretized using a collocation scheme with 20 finite elements
    # and 4 collocation points per finite element.
    # Increasing the number of finite elements will improve the solution quality but,
    # it will also increase the solution time.  In our example, oweing to the small problem size,
    # increasing the number of finite elements will not impact the solution time drastically.
    disc.apply_to(m, nfe=20, ncp=4)

    return m
