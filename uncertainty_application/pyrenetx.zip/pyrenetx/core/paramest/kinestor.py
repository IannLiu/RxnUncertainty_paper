import pandas as pd
from pyomo.environ import *
from pyomo.dae import *
from pyomo.core.expr import current as EXPR
from pyomo.core.expr.current import clone_expression
import pyomo.contrib.parmest.parmest as parmest
import numpy as np
import matplotlib.pyplot as plt
import itertools
import time


def create_data_dict(files):
    '''
    Create a list of dictionaries from multiple datasets
    Arguments:
        files: pandas dataframe of file names
    Return:
        data_dict_list: list of dictionaries
    '''
    data_dict_list = []
    for index, file in files.iterrows():
        # create a dictionary of 'experimental' data for temperature T and initial concentration of A CA0
        data_dict = {}
        data = pd.read_csv(str(file.values[0]), index_col=0)
        data_dict['T'] = data['T'].iloc[0]
        data_dict['CA0'] = data['CA0'].iloc[0]
        data = data.drop(labels=['T', 'CA0'], axis=1)
        data_dict['data'] = data
        # add dictionary to list to be return
        data_dict_list.append(data_dict)
    return data_dict_list


class Constant:
    """
    Read and write the constant
    """

    def __init__(self):
        self.R = 8.31446261815324

    def get_constant(self, con_name: str):
        return getattr(self, con_name)


class ReactionModel:
    """
    This is the main model block
    """

    def __init__(self, model_name=None):
        """
        Initialize the model
        :param model_name: The name of the generated model
        """
        self.KinEstObj = None
        self.model_name = model_name if model_name is not None else 'Model-1'
        self.component_names = []
        self.param_names = []
        self.parmestor = None
        self.nfe = 20
        self.ncp = 4
        self.odes_dict = {}
        self.component_dict = {}
        self.param_dict = {}
        self.old_id_to_name = {}
        self.data = None

    def _make_set_up_model(self):
        """Make the dummy model for initial pyomo vars
        """
        self._set_up_model = ConcreteModel()

        return None

    def _component(self, name_str, **kwargs):
        """
        Creates the initial pyomo variables for model building
        :param name_str: The name of the component
        :return: The Pyomo variable representing the component
        """
        if not hasattr(self, '_set_up_model'):
            self._make_set_up_model()
        sets = Set(initialize=[0])

        setattr(self._set_up_model, name_str, Var(sets, initialize=1))
        var = getattr(self._set_up_model, name_str)
        return var[0]

    def set_temperature(self, temp=None):
        if not hasattr(self, '_set_up_model'):
            self._make_set_up_model()
        if temp:
            setattr(self._set_up_model, "T", Param(initialize=temp))
            return self._set_up_model.T
        else:
            setattr(self._set_up_model, "T", Var(initialize=298))
            self._set_up_model.T.fix(298)
            temperature = self._set_up_model.T
            self.old_id_to_name[id(temperature)] = "T"
            return temperature

    def form_rate_constant(self, con_name, rules):
        """
        Form the rate constant if the fitted parameters are kinetic parameters
        :param con_name: the name of the rate constant
        :param rules: The rules for calculating rate constant
        :return: the Expression object of pyomo
        """
        setattr(self._set_up_model, con_name, Expression(rule=rules))

        return getattr(self._set_up_model, con_name)

    def component(self, _name, **kwargs):
        """
        Add reaction species
        :param _name:
        :return:
        """
        self.component_names.append(_name)
        self.component_dict.update(**{_name: kwargs})
        var = self._component(_name, **kwargs)
        self.old_id_to_name[id(var)] = _name
        return var

    def parameter(self, _name, **kwargs):

        """
        :param _name:
        :return:
        """
        self.param_names.append(_name)
        self.param_dict.update(**{_name: kwargs})
        var = self._component(_name, **kwargs)
        self.old_id_to_name[id(var)] = _name
        return var

    def update_sim_param(self, name_str: str, **kwargs):
        """
        Update the simulation model parameters and variables
        This function should be used before the concrete pyomo model is built
        :param name_str: the name of the substituted parameters or variables
        :return: None
        """
        if name_str in self.param_names:
            self.param_dict.update(**{name_str: kwargs})
        elif name_str in self.component_names:
            self.component_dict.update(**{name_str: kwargs})

    def add_ode(self, ode_var, ode_expr):
        """Method to add an ode expression to the ReactionModel
        :param str ode_var: Component or state variable
        :param ode_expr: Expression for rate equation as an expression
        :type ode_expr: pyomo expression

        :return: None

        """
        self.odes_dict.update(**{ode_var: ode_expr})

        return ode_expr

    def add_data(self, data: list):
        """
        Add experiment data
        :param data:
        :return:
        """
        if self.data is None:
            self.data = data
        else:
            raise AttributeError("The data has already been loaded!")

    def change_time(self, final_expr, m, t):
        sub_dict = {}
        for idx in [id(v) for v in EXPR.identify_variables(final_expr)]:
            var_name = self.old_id_to_name[idx]
            if var_name in self.component_names:
                sub_dict[idx] = getattr(m, var_name)[t]
            elif var_name in self.param_names:
                sub_dict[idx] = getattr(m, var_name)
        if hasattr(m, "T"):
            sub_dict[id(self._set_up_model.T)] = getattr(m, "T")
        return clone_expression(final_expr, sub_dict)

    def _add_odes(self, m):
        # add kinetic constrain
        if isinstance(self.odes_dict, dict):
            def rule_ode(m, t, k):
                exprs = self.odes_dict
                deriv_var = f'd{k}dt'
                return getattr(m, deriv_var)[t] == self.change_time(exprs[k], m, t)

            for key, val in self.odes_dict.items():
                setattr(m, f'd{key}dt', DerivativeVar(getattr(m, key)))
                setattr(m, f'{key}_rate', Constraint(m.t, [key], rule=rule_ode))
        return m

    def _kinest_core(self, data, time_col=None):
        """
        Create a pyomo model with loaded data for parameter estimation
        :param data: the pd.DataFrame object
        :param time_col: the name of the experiment time
        :return: a generated pyomo model with loaded data
        """
        exp_data = data['data']
        pyomo_model = ConcreteModel()
        pyomo_model.T = Param(initialize=data["T"])
        # pyomo_model.T.fix(data["T"])

        # load_time
        if time_col:
            t_exp = exp_data[time_col]
            self.time_col_name = time_col
        elif "time" in exp_data.columns.to_list():
            t_exp = exp_data["time"]
            self.time_col_name = "time"
        else:
            raise AttributeError("Experiment time should be specified !")
        pyomo_model.t = ContinuousSet(bounds=(t_exp.iloc[0], t_exp.iloc[-1]), initialize=t_exp.tolist())

        # Get initial conditions
        for component_name in self.component_names:
            if f'{component_name}0' in data.keys():
                setattr(pyomo_model, f'{component_name}0', data[f'{component_name}0'])
            elif component_name in exp_data.columns.to_list():
                setattr(pyomo_model, f'{component_name}0', exp_data[component_name][0])
            else:
                raise AttributeError("Error component name !")

        # load experiment data
        for component_name in self.component_names:
            dic = {}
            for time_point, data_point in zip(t_exp, exp_data[component_name]):
                dic[time_point] = data_point
            setattr(pyomo_model, component_name + "_exp", Param(pyomo_model.t, initialize=dic))

        # Generate parameters
        for key, val_dict in self.param_dict.items():
            initialize = None
            if "initialize" in val_dict.keys():
                initialize = val_dict["initialize"]
            bounds = None
            if "bounds" in val_dict.keys():
                bounds = val_dict["bounds"]
            setattr(pyomo_model, key, Var(initialize=initialize, bounds=bounds))

        # Generate components
        for key, val_dict in self.component_dict.items():
            bounds = None
            if "bounds" in val_dict.keys():
                bounds = val_dict["bounds"]
            setattr(pyomo_model, key, Var(pyomo_model.t,
                                          initialize=getattr(pyomo_model, f'{key}0'),
                                          bounds=bounds))

        # add initial condition constrain
        def _initcon(m):
            for name_str in self.component_names:
                yield getattr(m, name_str)[m.t.first()] == getattr(m, f'{name_str}0')

        pyomo_model.initcon = ConstraintList(rule=_initcon)

        # add kinetic constrain
        pyomo_model = self._add_odes(pyomo_model)

        def ComputeFirstStageCost_rule(m):
            # In this case, we do not optimize anything besides the kinetic parameters through
            # least square fitting realizations at each timestep defined by m.t.
            # Hence, the first stage cost is set to 0 here.
            return 0

        pyomo_model.FirstStageCost = Expression(rule=ComputeFirstStageCost_rule)

        def ComputeSecondStageCost_rule(m):
            return sum((getattr(m, name_str)[t] - getattr(m, f'{name_str}_exp')[t]) ** 2
                       for name_str in self.component_names for t in pyomo_model.t)

        pyomo_model.SecondStageCost = Expression(rule=ComputeSecondStageCost_rule)

        def total_cost_rule(m):
            return m.FirstStageCost + m.SecondStageCost

        pyomo_model.Total_Cost_Objective = Objective(rule=total_cost_rule, sense=minimize)

        disc = TransformationFactory('dae.collocation')
        disc.apply_to(pyomo_model, nfe=self.nfe, ncp=self.ncp)
        setattr(self, "est_model", pyomo_model)

        return pyomo_model

    def set_simulate_time(self, start_time=0, end_time=None):
        """
        Set the simulation time
        :param start_time:
        :param end_time:
        :return:
        """
        setattr(self, "start_time", start_time)
        if end_time:
            setattr(self, "end_time", end_time)

    def _kin_sim_core(self):
        """
        Create a pyomo Concrete model for simulation
        :return:
        """
        pyomo_model = ConcreteModel()
        # load parameters
        for key, val_dict in self.param_dict.items():
            if "initialize" in val_dict.keys():
                setattr(pyomo_model, key, Param(initialize=val_dict["initialize"]))

        # load time
        if hasattr(self, "start_time") and hasattr(self, "end_time"):
            pyomo_model.t = ContinuousSet(bounds=(self.start_time, self.end_time))
        else:
            raise AttributeError("Please set start and end time!")

        # load component
        for key, val_dict in self.component_dict.items():
            if "initialize" in val_dict.keys():
                initialize = val_dict["initialize"]
            else:
                raise AttributeError("Please set the initional condition of component {}".format(key))
            bounds = None
            if "bounds" in val_dict.keys():
                bounds = val_dict["bounds"]
            setattr(pyomo_model, key, Var(pyomo_model.t, initialize=initialize, bounds=bounds))

        # set odes
        pyomo_model = self._add_odes(pyomo_model)

        return pyomo_model

    @staticmethod
    def param_ident(cov, theta_names: list, show_info=False):
        """
        function for
        :param cov: the cov
        :param theta_names:
        :return:
        """
        # Fisher information matrix can be computed using the inverse of the reduced Hessian
        fim = np.linalg.inv(cov)

        # Eigen decomposition of the Fisher information matrix
        eig_values, eig_vectors = np.linalg.eig(fim)
        if show_info:
            for i, eig in enumerate(eig_values):
                print('***************************************************************')
                print('\nEigen value: {:0.3e}\n'.format(eig))
                print('=== Eigen vector elements with correspondng parameter names ===\n')
                print('------------------------------')
                print('| Vector element | Parameter |')
                print('------------------------------')
                for j, theta_name in enumerate(theta_names):
                    if eig_vectors[i, j] < 0.0:
                        print('|   {:0.3e}   |    {}     |'.format(eig_vectors[i, j], theta_name))
                    else:
                        print('|   {:0.3e}    |    {}     |'.format(eig_vectors[i, j], theta_name))
                print('\n')

        """
        The eigenvector corresponding to the smallest eigenvalue denotes the direction
        of least variance in the parameter space. The parameter that corresponds to the 
        major contributor in the eigenvector, then, has the lowest impact on model fit quality. 
        Thus, this parameter is considered sloppy and fixing it's value 
        will not affect overall model behavior.
        """
        param_ident_dict = {"lowest_eigen_value": eig_values[-1],
                            "parameter_name": theta_names,
                            "eigen_vector": eig_vectors[-1, :],
                            }

        return param_ident_dict

    def opt(self, cal_cov=False, cov_n=None):
        if self.data is None:
            raise AttributeError("Please load data firstly!")
        else:
            theta_names = self.param_names
            pest = parmest.Estimator(self._kinest_core, self.data, theta_names, tee=True)
            if cal_cov and cov_n:
                obj, theta, cov = pest.theta_est(calc_cov=cal_cov, cov_n=cov_n)
                setattr(self, "est_theta", theta)
                setattr(self, "est_theta_names", theta_names)
                param_ident_dict = self.param_ident(cov, theta_names)
                return [theta, param_ident_dict]
            else:
                obj, theta = pest.theta_est()
                setattr(self, "est_theta", theta)
                setattr(self, "est_theta_names", theta_names)
                return theta

    def simulate(self,
                 package='scipy',
                 numpoints=1000,
                 integrator='vode',
                 model: ConcreteModel = None,
                 integrator_options: dict = None):
        """
        Create simulation model
        :param package:
        :param numpoints:
        :param integrator:
        :param model: a pyomo model. if not given, a new pyomo model is generated.
        :param integrator_options: Dictionary containing options that should be passed to the integrator.
        :return:
        """
        if model is None:
            pyomo_model = self._kin_sim_core()
        else:
            pyomo_model = model
        sim = Simulator(pyomo_model, package=package)
        tsim, profiles = sim.simulate(numpoints=numpoints,
                                      integrator=integrator,
                                      integrator_options=integrator_options)
        names = self.odes_dict.keys()
        sim_results = pd.DataFrame(profiles, columns=list(names))
        sim_results["time"] = tsim
        setattr(self, "sim_model", pyomo_model)
        setattr(self, "sim_results", sim_results)

        return sim_results

    def plot(self):
        if hasattr(self, "sim_results"):
            pass
        elif hasattr(self, "est_results"):
            pass

    def print_model(self):
        """
        Print the model structure
        :return:
        """
        if hasattr(self, "est_model"):
            self.est_model.pprint()
        elif hasattr(self, "sim_model"):
            self.sim_model.pprint()
        elif hasattr(self, "_set_up_model"):
            self._set_up_model.pprint()
        else:
            raise AttributeError("The model has not been constructed!")

    def _est_to_sim(self, data: dict):
        """
        Convert estimation model to simulation model

        :param data:
        :return:
        """
        if hasattr(self, "est_model"):
            if hasattr(self, "est_theta") and hasattr(self, "est_theta_names"):
                # maybe we should rebuild a new pyomo model
                # Note that the fitted parameters should be a pyomo.Param object
                pyomo_model = ConcreteModel()

                # firstly, the simulated time should be loaded
                exp_data = data["data"]
                time_col_name = self.time_col_name
                if time_col_name in data.keys():
                    start_time = data[time_col_name]
                    end_time = exp_data["time"][-1]
                else:
                    print(exp_data["time"])
                    start_time = exp_data["time"].iloc[0]
                    end_time = exp_data["time"].iloc[-1]
                pyomo_model.t = ContinuousSet(bounds=(start_time, end_time))

                # set new temperature
                pyomo_model.T = Param(initialize=data["T"])

                # add components
                for component_name in self.component_names:
                    if f'{component_name}0' in data.keys():
                        initialize = data[f'{component_name}0']
                    elif component_name in exp_data.columns.to_list():
                        initialize = exp_data[component_name].iloc[0]
                    else:
                        raise AttributeError("Error component name !")
                    setattr(pyomo_model, component_name, Var(pyomo_model.t, initialize=initialize))

                # Add the fitted parameters
                for i, name_str in enumerate(self.est_theta_names):
                    setattr(pyomo_model, name_str, Param(initialize=self.est_theta[i]))
                pyomo_model = self._add_odes(pyomo_model)
                return pyomo_model

            else:
                raise AttributeError(" the parameters haven't been estimated ")
        else:
            raise AttributeError(" the model hasn't been added ! ")

    def report(self, **kwargs):
        """
        Report the model results or users

        Note: This function can only plot the model and(or) experiment data at present.
        :return:
        """
        if hasattr(self, "est_model"):
            assert (hasattr(self, "data") == True)
            if hasattr(self, "est_theta") and hasattr(self, "est_theta_names"):
                package = "scipy"
                numpoints = 100
                integrator = 'vode'
                items = kwargs.keys()
                if "package" in items:
                    package = kwargs["package"]
                if "numpoints" in items:
                    numpoints = kwargs["numpoints"]
                if "integrator" in items:
                    integrator = kwargs["integrator"]

                results = []
                plt.figure()
                for i, data in enumerate(self.data):
                    pyomo_model = self._est_to_sim(data)
                    sim = Simulator(pyomo_model, package=package)
                    tsim, profiles = sim.simulate(numpoints=numpoints,
                                                  integrator=integrator)
                    names = self.component_names
                    sim_results = pd.DataFrame(profiles, columns=names)
                    sim_results["time"] = tsim
                    results.append(sim_results)
                    plt.figure(i)
                    self.plot_data(plt, data_list=[self.data[i]["data"], sim_results],
                                   data_type=["experiment", "simulation"])

                plt.show()
                return results
            else:
                raise AttributeError(" the parameters haven't been estimated ")

        elif hasattr(self, "sim_model"):
            if hasattr(self, "sim_results"):
                plt.figure()
                self.plot_data(plt, [self.sim_results], data_type=["simulation"])
                plt.show()
            else:
                raise AttributeError(" the model haven't been simulated ")
        else:
            raise AttributeError(" Please construct a concrete model ")

    def plot_data(self, plt_i, data_list: list, data_type=None, path=None):
        """
        plot the data for given dataframe
        :param plt_i:
        :param data_list:
        :param data_type: ["experiment", "simulation]
        :param path:
        :return:
        """
        if data_type is None:
            data_type = ["experiment", "simulation"]
        if len(data_list) is not len(data_type):
            raise ValueError("the specified number of dataframe should match the number of datatype")

        # plt.figure(ith)
        for _type, data in zip(data_type, data_list):
            column_names = data.columns.to_list()
            if hasattr(self, "time_col_name"):
                if self.time_col_name in column_names:
                    time_points = data[self.time_col_name]
                    column_names.remove(self.time_col_name)
            elif "time" in column_names:
                time_points = data["time"]
                column_names.remove("time")
            else:
                raise AttributeError(" Time points have not been added ")

            marker = itertools.cycle(('o', 's', '<', '>', '^', 'v', '*'))
            if _type == "simulation":
                for column_name in column_names:
                    plt_i.plot(time_points, data[column_name], '-', label=f'{column_name}_sim')
            elif _type == "experiment":
                for column_name in column_names:
                    plt_i.scatter(time_points, data[column_name], marker=next(marker), label=f'{column_name}_exp')
            else:
                raise AttributeError("Unknown data type")

        if path:
            plt_i.savefig(path)

        plt.legend()

        return None

    @property
    def raw_model(self):

        return self._kin_sim_core()

