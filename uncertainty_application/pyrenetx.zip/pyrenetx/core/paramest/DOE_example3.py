import pandas as pd
from pyomo.environ import *
import kinestor

if __name__ == "__main__":
    # declare model
    m = kinestor.ReactionModel()
    k = [0.89197, 0.26069, 0.24870, 0.48183, 0.60977, -0.01301]
    CA = m.component("CA", initialize=1)
    CB = m.component("CB", initialize=0)
    CC = m.component("CC", initialize=0)
    CD = m.component("CD", initialize=0)
    m.set_simulate_time(start_time=0, end_time=6)
    m.add_ode("CA", -k[0] * CA - k[1] * CA)
    m.add_ode("CB", k[0] * CA - k[3] * CC - k[2] * CB - k[4] * CB)
    m.add_ode("CC", k[1] * CA - k[2] * CB - k[3] * CC - k[5] * CD)
    m.add_ode("CD", k[4] * CB - k[5] * CD)
    theta = m.simulate()
    m.report()

    print(theta)
