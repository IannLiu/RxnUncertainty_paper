import numpy as np
import pandas as pd
from kinestor import ReactionModel

class MD_DOE:
    """
    The main class for model discrimination
    """

    def __init__(self, design_name=None):
        """
        Initialize the model
        :param design_name: The name of the generated model
        """
        self.design_name = design_name
        self.models = {}

    def add_model(self, model_name, pyomo_model: ReactionModel):
        """
        Add the candidate kinetic models
        The added model should be the raw dummy models
        :param model_name: The name of the added model
        :param pyomo_model: The added models
        :return: None
        """
        name_list = self.models.keys()
        if model_name not in name_list:
            self.models[model_name] = pyomo_model
        else:
            raise AttributeError("The model name is used, please rename the model")

    class grid_search:

        def __init__(self):
            self.param_constraint = {}

        def add_constraint(self, name, bounds, step_size=None, step_number=None):
            """
            Add the model constraint
            :param name: the name of the parameter
            :param bounds: the bounds of the parameter
            :param step_size: the discrete step of the defined parameter
            :param step_number: the number of discrete points
            :return: None
            """
            if step_size:
                self.param_constraint[name] = np.arange(bounds[0], bounds[1], step_size)
            elif step_number:
                self.param_constraint[name] = np.linspace(bounds[0], bounds[1], step_number)
            else:
                raise AttributeError("Please specify the step_size or step_number")

        def search(self):
            """
            Search the experiment conditions
            :return:
            """
            pass





