from pyomo.environ import *
import kinestor

if __name__ == "__main__":

    # declare model

    m = kinestor.ReactionModel()

    # load reaction constants
    Constants = kinestor.Constant()
    R = Constants.get_constant(con_name="R")
    # T = 250

    A1 = m.parameter("A1", initialize=176.857562)
    A2 = m.parameter("A2", initialize=418.213917)
    E1 = m.parameter("E1", initialize=9.937390)
    E2 = m.parameter("E2", initialize=15.098089)

    T = m.set_temperature(temp=400)
    k1 = A1 * exp(-E1*1000/(R*T))
    k2 = A2 * exp(-E2*1000/(R*T))
    m.set_simulate_time(start_time=0, end_time=1)
    CA = m.component("CA", initialize=2)
    CB = m.component("CB", initialize=0)
    CC = m.component("CC", initialize=0)
    m.add_ode("CA", -k1 * CA)
    m.add_ode("CB", k1 * CA - k2 * CB)
    m.add_ode("CC", k2 * CB)
    theta = m.simulate()
    m.print_model()
    print(theta)
