import matplotlib.pyplot as plt
from networkx.algorithms import approximation as approx
import networkx as nx
from typing import Union, List, Any
from .chembase import Reaction, RunReactions, Molecule
from .parsing import ParsingReaction
from .util import SetSymm
from itertools import combinations
import warnings
from rdkit import Chem

warnings.filterwarnings('ignore')


class ReNet(RunReactions):
    """
    A wrapper of neteworkx(https://networkx.org/) for reaction network construction

    A reaction network are represented by directed graph in which:
    nodes and edges are molecule and reactions respectively
    """

    def __init__(self,
                 name: str = None,
                 explicit_hydrogens: bool = True,
                 symmetry: bool = True,
                 network: nx.DiGraph = None,
                 spenet: nx.DiGraph = None):
        """

        Args:
            name:
            explicit_hydrogens:
            symmetry:
        """
        super().__init__(explicit_hydrogens=explicit_hydrogens)
        if name is not None:
            self._name = name
        else:
            self._name = "reaction network"

        self._network = nx.DiGraph() if network is None else network
        self._spenet = nx.DiGraph() if spenet is None else spenet
        self._symmetry = symmetry

    def __str__(self):

        return self._name

    def initialize(self, cspecies: str):
        """
        Add the initial reactants
        Args:
            cspecies: core species

        Returns: None

        """
        setattr(self, "_seed", cspecies)

    def add_species(self, molecule: Union[str, List[str]], **attr):
        """
        Add a species
        Args:
            molecule:
            attr: attribute of molecule
        Returns: None
        """
        name = type(molecule).__name__
        if name == "list":
            smis = '.'.join(molecule)
        else:
            smis = molecule

        for mol in Molecule(smis, explicit_hydrogens=False):
            node = mol.drop_map_num().smiles
            self._network.add_node(node, **attr)

    def remove_species(self, species: Union[str, List[str]]):
        """
        Remove sepcies and related edges
        Args:
            species: The species to be deleted

        Returns: None

        Note: Removing species is NOT recommended. Removing 
        """
        name = type(species).__name__
        if name == "list":
            smis = '.'.join(species)
        else:
            smis = species

        # Note: deleting species and reactions that generated from given species
        related_nodes = []
        nodes_to_be_delet = [mol.drop_map_num().smiles for mol in Molecule(smis, explicit_hydrogens=False)]
        all_nodes = list(self._network.nodes)
        rest_nodes = [n for n in all_nodes if n not in nodes_to_be_delet]
        for node in nodes_to_be_delet:
            for n in rest_nodes:
                if approx.local_node_connectivity(self._network, node, n) > 0:
                    related_nodes.append(node)
        nodes_to_be_delet.extend(related_nodes)

        final_nodes = [n for n in all_nodes if n not in nodes_to_be_delet]
        sub_graph = self._network.subgraph(final_nodes)

        return sub_graph

    def add_stoichiom(self, reaction: Union[str, ParsingReaction], prop: dict = dict({}), name: str = None):
        """

        Args:
            reaction:
            prop:
            name:

        Returns:
        """
        if type(reaction).__name__ == "str":
            rxn = ParsingReaction(name, reaction)
        else:
            rxn = reaction
        reactant_list, product_list = [], []
        reactant_list.extend('.'.join([key] * value) for key, value in rxn.reactants.items())
        product_list.extend('.'.join([key] * value) for key, value in rxn.products.items())
        reaction_string = '{} -> {}'.format('.'.join(sorted(reactant_list)), '.'.join(sorted(product_list)))

        reaction_attr = {"reactant": '.'.join(sorted(reactant_list)),
                         "symmetry": [],
                         "product": {'.'.join(sorted(product_list)):
                                         {'.'.join(sorted(product_list)): prop, 'reaction_name': name}
                                     }}

        # Caution: The node may be updated!!!!!!!!
        self._spenet.add_node(reaction_string, **reaction_attr)

        for rk, rv in rxn.reactants.items():
            self._spenet.add_edge(rk, reaction_string)
            for pk, pv in rxn.products.items():
                if self._network.has_edge(rk, pk):
                    self._network.edges[rk, pk]['reaction'].add(reaction_string)
                else:
                    self._network.add_edge(rk, pk, reaction={reaction_string})
                self._spenet.add_edge(reaction_string, pk)

    def add_rxn(self, reaction: Union[str, Reaction], prop: dict = dict({}), explicit_hydrogens: bool = True,
                name: str = None):
        """
        Add edge to reaction networks
        The edge can be added by a reaction dictionary, a reaction class or a smiles string

        Args:
            reaction: the reaction used for add reaction edge
            prop: Other attributes such as reaction kinetic parameters
            explicit_hydrogens:
            name: reaction name

        Note: The reaction, reactant, product smiles have to be regularized by rdkit
        """
        # check atom map numbers
        if type(reaction).__name__ == "str":
            reaction = Reaction(reaction=reaction, explicit_hydrogens=explicit_hydrogens)
            rmols = reaction.reactant
            pmols = reaction.product
        else:
            rmols = reaction.reactant
            pmols = reaction.product
            name = reaction.name

        rsmi_ini = rmols.smiles
        psmi_ini = pmols.smiles
        rsmi_drop_H = rmols.drop_Hs_map_num().update(explicit_hydrogens=False).smiles
        psmi_drop_H = pmols.drop_Hs_map_num().update(explicit_hydrogens=False).smiles
        rmols.drop_map_num()
        pmols.drop_map_num()

        # Note: reaction smiles must be regularized using rdkit
        if rmols.smiles == '[H][H]' or rmols.smiles == '[H].[H]':
            reaction_smi = reaction.drop_map_number().reaction
            psmi_drop_H = psmi_ini
        else:
            reaction_smi = reaction.update(explicit_hydrogens=False).drop_map_number().reaction

        # add species nodes to species-property-network self._network
        for rmol in rmols:
            for pmol in pmols:
                if self._network.has_edge(rmol.smiles, pmol.smiles):
                    self._network.edges[rmol.smiles, pmol.smiles]['reaction'].add(reaction_smi)
                else:
                    self._network.add_edge(rmol.smiles, pmol.smiles, reaction={reaction_smi})

        # add reaction nodes to reaction-property-network self._spenet

        # reaction node exists ?
        if not self._spenet.has_node(reaction_smi):
            # if not, forming the initial reaction node property dictionary
            reaction_attr = {"reactant": rsmi_ini}
            if self._symmetry:
                sym_list = []
                syms = Molecule(smiles=rsmi_ini, explicit_hydrogens=False).drop_Hs_map_num().symmetry()
                for sym in syms:
                    if sym:
                        sym_list.extend(sym['symmetry'])
                reaction_attr["symmetry"] = sym_list
                to_be_add_prod = SetSymm(symm=sym_list, molecule=psmi_drop_H)
                reaction_attr["product"] = {to_be_add_prod: {psmi_ini: prop, 'reaction_name': name}}
            else:
                to_be_add_prod = psmi_drop_H
                reaction_attr["product"] = {to_be_add_prod: {psmi_ini: prop, 'reaction_name': name}}

            # add the property dictionary to reaction node, add corresponding species
            self._spenet.add_node(reaction.reaction, **reaction_attr)
            for rmol in reaction.reactant:
                self._spenet.add_node(rmol.smiles)
                self._spenet.add_edge(rmol.smiles, reaction.reaction)
            for pmol in reaction.product:
                self._spenet.add_node(pmol.smiles)
                self._spenet.add_edge(reaction.reaction, pmol.smiles)
        else:
            assert self._spenet.nodes[reaction_smi]["reactant"] == rsmi_ini, "Reactant have to be same, as well as " \
                                                                             "the atom mapped numbers(if set)"
            products_exist = self._spenet.nodes[reaction_smi]["product"].keys()
            if self._symmetry:
                to_be_add_prod = SetSymm(symm=self._spenet.nodes[reaction_smi]["symmetry"], molecule=psmi_drop_H)
            else:
                to_be_add_prod = psmi_drop_H
            if to_be_add_prod not in products_exist:
                self._spenet.nodes[reaction_smi]["product"][to_be_add_prod] = {psmi_ini: prop, 'reaction_name': name}
            else:
                # *************************************************
                # **Note: If already exist, update all properties**
                # *************************************************
                self._spenet.nodes[reaction_smi]["product"][to_be_add_prod] = {psmi_ini: prop, 'reaction_name': name}
                # for key, value in self._spenet.nodes[reaction_smi]["product"][to_be_add_prod].items():
                #    self._spenet.nodes[reaction_smi]["product"][to_be_add_prod][key] = prop

    def add_rxns_from(self, reactions: List[Union[str, Reaction]],
                      attrs: List[dict], explicit_hydrogens: bool = True):

        if len(attrs) == len(reactions):
            for reaction, attr in zip(reactions, attrs):
                self.add_rxn(reaction, attr, explicit_hydrogens=explicit_hydrogens)
        else:
            raise KeyError('The length of property list should match that of reaction list')

    def add_stoichioms_from(self, reactions: Union[str, ParsingReaction], props: List[dict], names: List[str] = None):
        if len(props) == len(reactions):
            if type(names).__name__ is None:
                for reaction, attr in zip(reactions, props):
                    self.add_stoichiom(reaction, attr)
            elif len(names) == len(reactions):
                for reaction, attr, name in zip(reactions, props, names):
                    self.add_stoichiom(reaction, attr, name=name)
            else:
                raise KeyError('The length of name list should match that of reaction list')
        else:
            raise KeyError('The length of property list should match that of reaction list')

    def load_rules(self, path: str = None, template: dict = None):
        """
        Loading reaction templates for network growth
        Args:
            path:
            template:

        Returns:
        """
        self.load_template(path=path, template=template)

    def add_rules(self, template: dict):
        """
        Add templates by given a template dict
        Args:
            template:

        Returns:

        """
        self.add_template(template=template)

    def drop_rules(self, template_name: Union[str, list]):
        """
        Drop template by template name
        Args:
            template_name:

        Returns:

        """
        self.drop_template(template_name=template_name)

    def react(self, max_react_molecules: int, max_rad_num: int = 3) -> list:

        """
        React with every sepcies in species pool

        Returns: a dict
        """
        current_pool = list(self._network.nodes)
        react_info = []

        for num in range(max_react_molecules):
            for nodes in combinations(current_pool, num + 1):
                info = self.run(".".join(nodes), maxRadicalElectrons=max_rad_num)
                react_info.append(info)

        return react_info

    def growth(self, steps: int = 0, max_react_molecules: int = 1, max_rad_num: int = 3):
        for _ in range(steps):
            react_info = self.react(max_react_molecules, max_rad_num=max_rad_num)
            # add reaction and attributes into network
            for info in react_info:
                for reactant, prod_info in info.items():
                    for temp_name, prods in prod_info.items():
                        for prod in prods.values():
                            self.add_rxn(reaction=">>".join([reactant, prod[0]]),
                                         prop={"template_name": temp_name})

    def _check_nodes(self, species: list):
        """
        Check whether the nodes in reaction network

        Args:
            species: the checked species
        Returns: the species out of present network
        """
        nodes = self._network.nodes

        return [nd for nd in species if nd in nodes]

    def _check_edges(self, edges: list, reaction: str):
        """
        Check whether the edge in reaction network

        Args:
            edges: the checked edges(only containing nodes).

        Returns: the edges out of reaction network
        """
        edge_list = self._network.edges.data()
        selected_edge = []
        for edge in edges:
            compared_edge = (*edge, {"reaction": reaction})
            if compared_edge not in edge_list:
                selected_edge.append(compared_edge)

        return selected_edge

    def get_reactions(self, v, n, default: Any = None):
        """
        Returns the reactions associated with edge (u, v).
        Args:
            v: species 1
            n: species 2
            default: Return default if not found
        Returns: reactions and corresponding attribute(v -> n)
        """

        if self._network.has_edge(v, n):
            return self._network.edges[v, n]
        else:
            return default

    def get_reaction_info(self, reaction: Union[str, Reaction], default: Any = None) -> list:
        """
        Returns the reactions associated with edge (u, v).
        Args:
            reaction:
            default: Return default if not found
        Returns: reactions and corresponding attribute(v -> n)
        """
        if type(reaction).__name__ == 'str':
            reaction_smi = Reaction(reaction=reaction, explicit_hydrogens=False).drop_map_number().reaction
        else:
            reaction_smi = reaction.drop_map_number().reaction
        if self._spenet.has_node(reaction_smi):
            return self._spenet.nodes[reaction_smi]
        else:
            return default

    def get_predecessors(self, molecule: Union[str, Molecule], default: Any = None):
        """
        Get all the nodes of which products is given molecule
        Args:
            molecule:
            default:

        Returns: A list
        """
        if type(molecule).__name__ == 'str':
            try:
                molecule = Chem.MolToSmiles(Chem.MolFromSmiles(molecule))
            except:
                molecule = molecule
        else:
            molecule = molecule.smiles
        if self._network.has_node(molecule):
            return list(self._network.predecessors(molecule))  # return a key_iterator
        else:
            return default

    def get_successors(self, molecule: Union[str, Molecule], default: Any = None):
        """
        Get all nodes of which reactants is given molecule
        Args:
            molecule:
            default:

        Returns:

        """
        if type(molecule).__name__ == 'str':
            try:
                molecule = Chem.MolToSmiles(Chem.MolFromSmiles(molecule))
            except:
                molecule = molecule
        else:
            molecule = molecule.smiles
        if self._network.has_node(molecule):
            return list(self._network.successors(molecule))  # return a key_iterator
        else:
            return default

    def get_pathways(self, s, t):
        """
        Return all pathways between v -> n
        Args:
            s: Source
            t: Target

        Returns:

        """
        assert s != t, "Source and target have to be different nodes"

        def get_paths(net, source, target):
            all_nodes = list(net.nodes)
            all_nodes.remove(source)
            all_nodes.remove(target)
            in_paths = []
            for node in all_nodes:
                if approx.local_node_connectivity(net, source, node) > 0 and \
                        approx.local_node_connectivity(net, node, target) > 0:
                    in_paths.append(node)
            sub_graph = net.subgraph(in_paths)

            return sub_graph

        sub_species_net = get_paths(self._network, s, t)
        sub_rxn_net = get_paths(self._spenet, s, t)

        return ReNet(name=self.name,
                     explicit_hydrogens=self._explicit_hydrogens,
                     symmetry=self._symmetry,
                     network=sub_species_net,
                     spenet=sub_rxn_net)

    def display(self):
        """

        """
        graph = self._network
        pos = nx.spring_layout(graph, seed=1)
        labels = dict({})
        for node in graph.nodes:
            labels[node] = node
        nx.draw_networkx(graph, pos=pos, arrows=True, labels=labels)
        plt.show()

    def merge(self, network):
        """
        Merge network with others
        Args:
            network:

        Returns: None

        """
        self._name = '.'.join([self._name, network.name]) if self._name != network.name else self._name
        self._symmetry = self._symmetry | network.symmetry
        self._network = nx.union(self._network, network.network)
        self._spenet = nx.union(self._spenet, network.reaction_graph)

    @property
    def species(self) -> list:
        """
        Return the species pool
        Returns: A species dictionary
        """

        return list(self._network.nodes)

    @property
    def network(self):
        """
        Return network object
        Returns: A networkx object
        """
        return self._network

    @property
    def reaction_pool(self):
        """
        Return reaction information
        """
        return [node for node in self._spenet.nodes if '>' in node]

    @property
    def atom_mapped_reaction_pool(self):
        mapped_pool = []
        for reaction in self.reaction_pool:
            rsmi = self._spenet.nodes[reaction]['reactant']
            prods_dic = self._spenet.nodes[reaction]['product']
            for _, psmi_dic in prods_dic.items():
                for psmi in psmi_dic.keys():
                    if psmi != 'reaction_name':
                        mapped_pool.append('{}>>{}'.format(rsmi, psmi))
        return mapped_pool

    @property
    def reaction_infos(self):
        """
        Get reaction information
        Returns:

        """
        infos = []
        reactions = []
        for reaction in self.reaction_pool:
            infos.append(self._spenet.nodes[reaction])
            reactions.append(reaction)

        return reactions, infos

    @property
    def atom_mapped_reaction_infos(self):
        """
        Get atom mapped reaction information
        Returns:
        """
        infos = []
        reactions = []
        for reaction in self.reaction_pool:
            infos.append(self._spenet.nodes[reaction])
            reactions.append(reaction)

        return reactions, infos

    @property
    def reaction_graph(self):

        return self._spenet

    @property
    def name(self):

        return self._name

    @property
    def symmetry(self):

        return self._symmetry

    def node_info(self, rxn):

        return self._spenet.nodes[rxn]
