import operator
import ast

# define operator map between python operator and ast operator
OP_MAP = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Invert: operator.neg,
    ast.Pow: operator.pow,
    ast.Mod: operator.mod,
}


class ParsingReaction(object):
    """
    A simple class to hold the stoichiometry of a single reaction

    Reaction data is stored in two dictionaries:
       reactants: a map of reactant species name -> stoichiometric coefficient
       products: a map of product species name -> stoichiometric coefficient
    """

    def __init__(self, reactants: str, products: str = None, name: str = None, is_smarts: bool = True):

        """
        Define a reaction.  The reaction can be specified either as
        a text string:

            Reaction("2*A + B -> C + 3*D")

        or reactant and product strings:

            Reaction(reactants="2*A + B", products="C + 3*D")

        or lists of terms reactant and product strings:

            Reaction(reactants=["2*A","B"], products=["C","3*D"])

        or lists of (coef, name) tuples:

            Reaction(reactants=[(2,"A"),(1,"B")], products=[(1,"C"),(3,"D")])

        or molecule smiles(smiles type):

            Reaction(react = 'A.B', product = 'C.D')

        or reaction smiles(smiles type):

            Reaction(react = 'A.B>>C.D')
        """
        # Assert whether reaction/reactant/product expressed by SMILES
        self._smiles_type = is_smarts
        self._rxn_smarts = None

        if products is None:
            if self._smiles_type:
                self._rxn_smarts = reactants
                reactants, agent, products = reactants.split('>')
            elif '->' in reactants:
                reactants, products = reactants.split('->')
            else:
                raise KeyError('Unknown reaction string')
        if self._rxn_smarts is None and self._smiles_type:
            self._rxn_smarts = '{}>>{}'.format(reactants, products)
        self.name = name
        self.reactants = self._parse(reactants)
        self.products = self._parse(products)

    def _parse(self, _in):
        ans = {}
        if isinstance(_in, str):
            if not self._smiles_type:
                _in = _in.split('+')
                for x in _in:
                    coef, species = self._parseTerm(x)
                    ans[species] = ans.get(species, 0) + coef
            else:
                _in_smis = _in.split('.')
                for smi in _in_smis:
                    ans[smi] = ans.get(smi, 0) + 1
        return ans

    def _parseTerm(self, x):

        if isinstance(x, str):
            if '*' in x:
                coef, species = x.split('*', 1)
                coef = float(coef)
            else:
                coef, species = 1, x
        else:
            coef, species = x
            coef = float(coef)
        return coef, species.strip()

    @property
    def smiles_type(self):

        return self._smiles_type

    @property
    def smarts(self):

        return self._rxn_smarts


class ReplaceName(ast.NodeTransformer):
    """
    Visiting abstract syntax tree and modify the given nodes mapped by replace_dict
    """

    def __init__(self, **kwargs):
        super().__init__()
        self.replace_dict = kwargs

    def visit_BinOp(self, node):
        left = self.visit(node.left)
        right = self.visit(node.right)
        return OP_MAP[type(node.op)](left, right)

    def visit_Name(self, node):
        if node.id in self.replace_dict.keys():
            return self.replace_dict[node.id]
        return node

    def visit_Num(self, node):

        return node.n


def ParsingExpression(expression: str, **replace_map):
    """
    Passing a string to python expression based object
    Args:
        expression: The string to be passed
        **replace_map: The replaced dictionary

    Returns:

    """
    expr = ast.parse(expression, mode='eval')
    replace = ReplaceName(**replace_map)
    replace.visit(expr)

    return expr.body
